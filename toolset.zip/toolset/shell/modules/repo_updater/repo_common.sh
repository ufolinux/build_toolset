##
# Here will be the common functions that are used by other repo modules
##

repo_fail_if_docker() {
    echo "Fail"
}
